## VS1053

The VS1053 is a chip that can decode Ogg Vorbis / MP3 / AAC / WMA / FLAC / MIDI 
So there is no need for the microcontroller to do any decoding.


