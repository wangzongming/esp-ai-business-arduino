# Test Output to SPDIF

We use the sine generator to generate a test tone and output it as SPDIF dignals to the indicated pin.
If you encounter some quality issues you can increase the DEFAULT_BUFFER_SIZE (e.g. to 2048) and I2S_BUFFER_SIZE/I2S_BUFFER_COUNT