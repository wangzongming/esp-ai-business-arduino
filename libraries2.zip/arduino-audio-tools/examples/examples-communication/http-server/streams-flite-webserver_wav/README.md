# Using FLITE Speach to Text

I am providing a simple sketch which generates sound data with the Flite text to speach engine.
You need to install https://github.com/pschatzmann/arduino-flite

In this demo we provide the result as WAV stream which can be listened to in a Web Browser

