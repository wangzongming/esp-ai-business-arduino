# Receive Sound Data from Bluetooth A2DP

We receive some music via Bluetooth e.g. from your mobile phone and display it as CSV