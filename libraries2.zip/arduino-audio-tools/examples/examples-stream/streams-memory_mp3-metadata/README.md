# Decoding a MP3 file with Metadata

In this example we provide the ID3 metadata from a MP3 file. We support the old ID3V1 and the newer ID3V2.
The MetaDataID3 class is used as stream output destination. 
You register your callback method with setCallback().
