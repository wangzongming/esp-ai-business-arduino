
This directory contains the implementations for analog audio input and output (on the ESP32). 

Other Arduino devices can only read data!
