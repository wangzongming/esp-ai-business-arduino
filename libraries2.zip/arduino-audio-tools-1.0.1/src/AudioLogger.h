#pragma once
// added so that we can include the AudioLogger from Arduino w/o calling include "AudioTools.h" first.
#include "AudioTools/CoreAudio/AudioLogger.h"